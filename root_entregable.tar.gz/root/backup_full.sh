#!/bin/bash

#Ofrecer ayuda
if [ "$1" = '-h' ]; then
	echo "---------Bienvenido al menu de ayuda----------"
	echo "Formato: $0 <directorio_origen> <directorio_destino>"
	echo "----------------------------------------------"
	exit 1
fi

# Verificar si se han proporcionado argumentos
if [ $# -ne 2 ]; then
	echo "Error en los argumentos <-h para ayuda>"
	echo "Formato: $0 <directorio_origen> <directorio_destino>"
	exit 1
fi


FECHA=$(date "+%Y%m%d")
backup_origen=$1
backup_destino=$2
name_file="$(basename $backup_origen)_bkp_$FECHA.tar.gz"


#Verificar que el directorio de origen exista y no este vacio

if [ -s $1 ] ; then
	#Verificar que el directorio de destino exista
	if [ -d $2 ]; then
		#Realizar Backup
		/bin/tar -cpzvf "$backup_destino/$name_file" "$backup_origen"

		if [ $? -eq 0 ]; then
		echo "Backup exitoso"
		else

		echo "ERROR"
		fi
	else
		echo "ERROR ---El directorio de destino no existe---" 	
	fi
else
	echo "ERROR ---El directorio de origen no existe o se encuentra vacio---"
	exit 1
fi
